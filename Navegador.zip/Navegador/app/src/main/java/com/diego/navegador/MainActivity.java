package com.diego.navegador;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.hardware.biometrics.BiometricManager;
import android.hardware.biometrics.BiometricPrompt;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.Environment;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.webkit.CookieManager;
import android.webkit.ServiceWorkerClient;
import android.webkit.ServiceWorkerController;
import android.webkit.SslErrorHandler;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebBackForwardList;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebViewDatabase;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends Activity {

    private static final String INICIO = "https://duckduckgo.com/";
    private static final String BUSCAR = "https://duckduckgo.com/?q=";

    private static final String PREFS = "ajustes";
    private static final String K_BLOQUEADAS = "bloqueadas";
    private static final String K_INICIADA = "iniciada";
    private static final String K_ANUNCIOS = "anuncios";
    private static final String K_HTTPS = "https";
    private static final String K_BORRAR = "borrarAlCerrar";
    private static final String K_HUELLA = "huella";
    private static final String K_TAM = "lectura_tam";
    private static final String K_TEMA = "lectura_tema";
    private static final String K_FUENTE = "lectura_fuente";
    private static final int REQ_ARCHIVO = 1;

    private WebView web;
    private EditText barra;
    private ProgressBar progreso;
    private View cortina;
    private SharedPreferences prefs;

    private volatile Set<String> bloqueadas = Collections.emptySet();
    private volatile Set<String> anuncios = Collections.emptySet();
    private volatile boolean bloquearAnuncios, forzarHttps, borrarAlCerrar, huellaActivada;

    private ValueCallback<Uri[]> archivoCallback;
    private String httpPendiente;
    private final Set<String> hostsHttpPermitidos = new HashSet<>();
    private boolean desbloqueado = false;
    private boolean autenticando = false;
    private boolean abriendoExterno = false;
    private String readabilityJs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean(K_INICIADA, false)) {
            Set<String> inicial = new HashSet<>();
            inicial.add("instagram.com");
            prefs.edit().putStringSet(K_BLOQUEADAS, inicial).putBoolean(K_INICIADA, true).apply();
        }
        Set<String> guardadas = new HashSet<>();
        for (String d : prefs.getStringSet(K_BLOQUEADAS, Collections.<String>emptySet())) {
            String limpio = limpiarDominio(d);
            if (!limpio.isEmpty()) guardadas.add(limpio);
        }
        bloqueadas = guardadas;
        bloquearAnuncios = prefs.getBoolean(K_ANUNCIOS, true);
        forzarHttps = prefs.getBoolean(K_HTTPS, true);
        borrarAlCerrar = prefs.getBoolean(K_BORRAR, false);
        huellaActivada = prefs.getBoolean(K_HUELLA, false);
        cargarListaAnuncios();

        web = findViewById(R.id.web);
        barra = findViewById(R.id.barra);
        progreso = findViewById(R.id.progreso);
        cortina = findViewById(R.id.cortina);
        Button atras = findViewById(R.id.atras);
        Button recargar = findViewById(R.id.recargar);
        Button menu = findViewById(R.id.menu);
        Button desbloquear = findViewById(R.id.desbloquear);

        aplicarSeguridadVentana();
        configurarWeb();
        limpiarDatosDeBloqueadas();
        if (borrarAlCerrar && savedInstanceState == null) borrarDatos();

        barra.setOnEditorActionListener((v, actionId, event) -> {
            boolean enter = event != null
                    && event.getKeyCode() == KeyEvent.KEYCODE_ENTER
                    && event.getAction() == KeyEvent.ACTION_DOWN;
            if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE || enter) {
                abrir(barra.getText().toString());
                return true;
            }
            return false;
        });

        atras.setOnClickListener(v -> irAtras());
        recargar.setOnClickListener(v -> web.reload());
        menu.setOnClickListener(this::mostrarMenu);
        desbloquear.setOnClickListener(v -> pedirHuella());

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else if (!abrirIntent(getIntent())) {
            cargar(INICIO);
        }
    }

    // =====================================================================
    //  Configuración del navegador
    // =====================================================================

    private void configurarWeb() {
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);

        // Endurecido: las webs no pueden leer archivos del móvil ni pedir ubicación
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setGeolocationEnabled(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setSafeBrowsingEnabled(true);
        WebView.setWebContentsDebuggingEnabled(false);

        // Sin cookies de terceros: no te siguen de una web a otra
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                String esq = u.getScheme() == null ? "" : u.getScheme().toLowerCase();
                if (esq.equals("lectura")) {
                    manejarLectura(u);
                    return true;
                }
                if (esq.equals("http") || esq.equals("https")) {
                    if (request.isForMainFrame() && estaBloqueada(u.getHost())) {
                        mostrarBloqueo(u.getHost());
                        return true;
                    }
                    if (request.isForMainFrame() && necesitaHttps(u)) {
                        cargar(u.toString());
                        return true;
                    }
                    return false;
                }
                return gestionarEnlace(u, esq);
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (estaBloqueada(host)) {
                    return respuesta(request.isForMainFrame() ? paginaBloqueada(host) : "");
                }
                if (!request.isForMainFrame() && esAnuncio(host)) {
                    return respuesta("");
                }
                return null;
            }

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                // Red de seguridad: si una web bloqueada llega a cargarse por otra vía
                // (caché, service worker, historial), se corta aquí.
                if (urlBloqueada(url)) {
                    mostrarBloqueo(Uri.parse(url).getHost());
                    return;
                }
                if (!esInterna(url) && !barra.hasFocus()) barra.setText(url);
                progreso.setVisibility(View.VISIBLE);
            }

            @Override
            public void doUpdateVisitedHistory(WebView view, String url, boolean isReload) {
                if (urlBloqueada(url)) mostrarBloqueo(Uri.parse(url).getHost());
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progreso.setVisibility(View.GONE);
                if (!esInterna(url) && !barra.hasFocus()) barra.setText(url);
                if (httpPendiente != null && url != null && url.startsWith("https://")) httpPendiente = null;
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) comprobarHttpsFallido(request.getUrl().getHost());
            }

            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.cancel(); // nunca se acepta un certificado no válido
                String host = error.getUrl() == null ? null : Uri.parse(error.getUrl()).getHost();
                if (!comprobarHttpsFallido(host)) {
                    Toast.makeText(MainActivity.this,
                            "Conexión bloqueada: el certificado de la web no es válido",
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int p) {
                progreso.setProgress(p);
                if (p >= 100) progreso.setVisibility(View.GONE);
            }

            @Override
            public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (archivoCallback != null) archivoCallback.onReceiveValue(null);
                archivoCallback = cb;
                try {
                    abriendoExterno = true;
                    startActivityForResult(params.createIntent(), REQ_ARCHIVO);
                } catch (Exception e) {
                    abriendoExterno = false;
                    archivoCallback = null;
                    return false;
                }
                return true;
            }
        });

        // Peticiones que hacen los service workers (por si una web intenta servirse desde ahí)
        ServiceWorkerController.getInstance().setServiceWorkerClient(new ServiceWorkerClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (estaBloqueada(host) || esAnuncio(host)) return respuesta("");
                return null;
            }
        });

        web.setDownloadListener((url, userAgent, contentDisposition, mime, length) -> {
            try {
                String nombre = URLUtil.guessFileName(url, contentDisposition, mime);
                DownloadManager.Request r = new DownloadManager.Request(Uri.parse(url));
                r.setMimeType(mime);
                r.addRequestHeader("User-Agent", userAgent);
                String cookies = CookieManager.getInstance().getCookie(url);
                if (cookies != null) r.addRequestHeader("Cookie", cookies);
                r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                r.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, nombre);
                ((DownloadManager) getSystemService(DOWNLOAD_SERVICE)).enqueue(r);
                aviso("Descargando " + nombre);
            } catch (Exception e) {
                aviso("No se pudo descargar");
            }
        });
    }

    // =====================================================================
    //  Navegación
    // =====================================================================

    /** Punto único para cargar una dirección: comprueba bloqueo y HTTPS. */
    private void cargar(String url) {
        Uri u = Uri.parse(url);
        if (estaBloqueada(u.getHost())) {
            mostrarBloqueo(u.getHost());
            return;
        }
        if (necesitaHttps(u)) {
            httpPendiente = url;
            url = u.buildUpon().scheme("https").build().toString();
        }
        web.loadUrl(url);
    }

    private void abrir(String texto) {
        String t = texto.trim();
        if (t.isEmpty()) return;
        String url;
        if (t.matches("(?i)^https?://.*")) {
            url = t;
        } else if (!t.contains(" ") && t.contains(".")) {
            url = "https://" + t;
        } else {
            url = BUSCAR + Uri.encode(t);
        }
        ocultarTeclado();
        cargar(url);
    }

    /** Atrás, saltándose páginas bloqueadas para no quedarse atascado. */
    private boolean irAtras() {
        WebBackForwardList h = web.copyBackForwardList();
        int actual = h.getCurrentIndex();
        for (int i = actual - 1; i >= 0; i--) {
            String u = h.getItemAtIndex(i).getUrl();
            if (!urlBloqueada(u) && !esInterna(u)) {
                web.goBackOrForward(i - actual);
                return true;
            }
        }
        return false;
    }

    /** Enlaces que no son web (teléfono, correo, apps...): se pregunta antes de abrir otra app. */
    private boolean gestionarEnlace(Uri u, String esq) {
        switch (esq) {
            case "about":
            case "data":
            case "blob":
            case "javascript":
                return false;
        }
        final Intent intent;
        try {
            if (esq.equals("intent")) {
                Intent i = Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME);
                i.addCategory(Intent.CATEGORY_BROWSABLE);
                i.setComponent(null);
                i.setSelector(null);
                intent = i;
            } else {
                intent = new Intent(Intent.ACTION_VIEW, u);
            }
        } catch (Exception e) {
            aviso("No se puede abrir este enlace");
            return true;
        }
        final String alternativa = intent.getStringExtra("browser_fallback_url");
        String hostAlt = alternativa == null ? null : Uri.parse(alternativa).getHost();
        if (estaBloqueada(u.getHost()) || estaBloqueada(hostAlt)) {
            mostrarBloqueo(estaBloqueada(u.getHost()) ? u.getHost() : hostAlt);
            return true;
        }

        String texto = u.toString();
        final String resumen = texto.length() > 120 ? texto.substring(0, 120) + "…" : texto;
        AlertDialog.Builder b = new AlertDialog.Builder(this)
                .setTitle("¿Abrir en otra app?")
                .setMessage(resumen)
                .setPositiveButton("Abrir", (d, w) -> {
                    try {
                        startActivity(intent);
                    } catch (Exception e) {
                        if (alternativa != null) cargar(alternativa);
                        else aviso("No hay ninguna app para abrir este enlace");
                    }
                })
                .setNegativeButton("Cancelar", null);
        if (alternativa != null) b.setNeutralButton("Seguir aquí", (d, w) -> cargar(alternativa));
        b.show();
        return true;
    }

    private void ocultarTeclado() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(barra.getWindowToken(), 0);
        barra.clearFocus();
        web.requestFocus();
    }

    private static boolean esInterna(String url) {
        return url == null || url.startsWith("about:") || url.startsWith("data:");
    }

    // =====================================================================
    //  Bloqueo de webs
    // =====================================================================

    private boolean estaBloqueada(String host) {
        if (host == null) return false;
        String h = host.toLowerCase();
        Set<String> lista = bloqueadas;
        for (String d : lista) {
            if (h.equals(d) || h.endsWith("." + d)) return true;
        }
        return false;
    }

    private boolean urlBloqueada(String url) {
        if (url == null || esInterna(url)) return false;
        return estaBloqueada(Uri.parse(url).getHost());
    }

    private void mostrarBloqueo(String host) {
        web.post(() -> {
            web.stopLoading();
            web.loadDataWithBaseURL(null, paginaBloqueada(host), "text/html", "utf-8", null);
            progreso.setVisibility(View.GONE);
            if (!barra.hasFocus()) barra.setText(host);
        });
    }

    /** Borra caché, service workers y datos guardados de las webs bloqueadas. */
    private void limpiarDatosDeBloqueadas() {
        WebStorage ws = WebStorage.getInstance();
        for (String d : bloqueadas) {
            for (String pre : new String[]{"https://", "https://www.", "https://m.", "http://", "http://www."}) {
                ws.deleteOrigin(pre + d);
            }
        }
    }

    private WebResourceResponse respuesta(String html) {
        return new WebResourceResponse("text/html", "utf-8",
                new ByteArrayInputStream(html.getBytes(StandardCharsets.UTF_8)));
    }

    private String paginaBloqueada(String host) {
        return "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<style>body{font-family:sans-serif;display:flex;align-items:center;justify-content:center;"
                + "height:90vh;margin:0;background:#fff;color:#202124;text-align:center}"
                + ".c{padding:24px}.i{font-size:64px}h1{font-size:22px;margin:12px 0 8px}"
                + "p{color:#5f6368;font-size:15px}</style></head><body><div class='c'>"
                + "<div class='i'>&#128683;</div><h1>Página bloqueada</h1>"
                + "<p><b>" + TextUtils.htmlEncode(host == null ? "" : host)
                + "</b> está en tu lista de webs bloqueadas.</p>"
                + "</div></body></html>";
    }

    private void editarBloqueadas() {
        EditText campo = new EditText(this);
        campo.setInputType(InputType.TYPE_CLASS_TEXT
                | InputType.TYPE_TEXT_FLAG_MULTI_LINE
                | InputType.TYPE_TEXT_VARIATION_URI);
        campo.setMinLines(5);
        campo.setGravity(Gravity.TOP | Gravity.START);
        List<String> orden = new ArrayList<>(bloqueadas);
        Collections.sort(orden);
        campo.setText(TextUtils.join("\n", orden));

        new AlertDialog.Builder(this)
                .setTitle("Webs bloqueadas")
                .setMessage("Una por línea. Ejemplo: instagram.com\nTambién bloquea sus subdominios.")
                .setView(enMarco(campo))
                .setPositiveButton("Guardar", (d, w) -> guardarBloqueadas(campo.getText().toString()))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void guardarBloqueadas(String texto) {
        Set<String> nuevas = new LinkedHashSet<>();
        for (String linea : texto.split("[\\s,;]+")) {
            String d = limpiarDominio(linea);
            if (!d.isEmpty()) nuevas.add(d);
        }
        List<String> quitadas = new ArrayList<>();
        for (String d : bloqueadas) {
            if (!nuevas.contains(d)) quitadas.add(d);
        }
        if (quitadas.isEmpty()) {
            aplicarBloqueadas(nuevas);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("¿Desbloquear?")
                .setMessage("Vas a desbloquear:\n\n" + TextUtils.join("\n", quitadas) + "\n\n¿Seguro?")
                .setPositiveButton("Sí, desbloquear", (d, w) -> aplicarBloqueadas(nuevas))
                .setNegativeButton("No", null)
                .show();
    }

    private void aplicarBloqueadas(Set<String> nuevas) {
        bloqueadas = new HashSet<>(nuevas);
        prefs.edit().putStringSet(K_BLOQUEADAS, new HashSet<>(nuevas)).apply();
        limpiarDatosDeBloqueadas();
        aviso("Lista guardada");
        String actual = web.getUrl();
        if (urlBloqueada(actual)) mostrarBloqueo(Uri.parse(actual).getHost());
        else web.reload();
    }

    private static String limpiarDominio(String s) {
        String d = s.trim().toLowerCase();
        d = d.replaceFirst("^[a-z][a-z0-9+.-]*://", "");
        d = d.split("[/?#:]", 2)[0];
        if (d.startsWith("www.")) d = d.substring(4);
        while (d.startsWith(".")) d = d.substring(1);
        return d;
    }

    // =====================================================================
    //  Anuncios y rastreadores
    // =====================================================================

    private void cargarListaAnuncios() {
        new Thread(() -> {
            Set<String> s = new HashSet<>(120000);
            try (BufferedReader r = new BufferedReader(
                    new InputStreamReader(getAssets().open("anuncios.txt"), StandardCharsets.UTF_8))) {
                String l;
                while ((l = r.readLine()) != null) {
                    l = l.trim();
                    if (!l.isEmpty()) s.add(l);
                }
            } catch (IOException ignored) {
            }
            anuncios = s;
        }).start();
    }

    private boolean esAnuncio(String host) {
        if (!bloquearAnuncios || host == null) return false;
        Set<String> s = anuncios;
        if (s.isEmpty()) return false;
        String h = host.toLowerCase();
        while (h.indexOf('.') > 0) {
            if (s.contains(h)) return true;
            h = h.substring(h.indexOf('.') + 1);
        }
        return false;
    }

    // =====================================================================
    //  HTTPS
    // =====================================================================

    private boolean necesitaHttps(Uri u) {
        return forzarHttps
                && "http".equalsIgnoreCase(u.getScheme())
                && u.getHost() != null
                && !hostsHttpPermitidos.contains(u.getHost().toLowerCase());
    }

    /** Si falló la versión segura de una web que pedimos por http, ofrece abrirla sin cifrar. */
    private boolean comprobarHttpsFallido(String host) {
        if (httpPendiente == null || host == null) return false;
        String hostPendiente = Uri.parse(httpPendiente).getHost();
        if (hostPendiente == null || !hostPendiente.equalsIgnoreCase(host)) return false;
        final String original = httpPendiente;
        httpPendiente = null;
        web.post(() -> new AlertDialog.Builder(this)
                .setTitle("Web sin cifrar")
                .setMessage(hostPendiente + " no admite conexión segura (HTTPS). "
                        + "Lo que veas o escribas ahí podría ser visible para otros en la red.\n\n¿Abrirla igualmente?")
                .setPositiveButton("Abrir sin cifrar", (d, w) -> {
                    hostsHttpPermitidos.add(hostPendiente.toLowerCase());
                    web.loadUrl(original);
                })
                .setNegativeButton("Cancelar", null)
                .show());
        return true;
    }

    // =====================================================================
    //  Privacidad: ajustes, borrar datos y huella
    // =====================================================================

    private void mostrarPrivacidad() {
        String[] opciones = {
                "Bloquear anuncios y rastreadores",
                "Forzar HTTPS (conexión cifrada)",
                "Borrar datos al cerrar",
                "Pedir huella al abrir"
        };
        boolean[] marcadas = {bloquearAnuncios, forzarHttps, borrarAlCerrar, huellaActivada};
        new AlertDialog.Builder(this)
                .setTitle("Privacidad")
                .setMultiChoiceItems(opciones, marcadas, (d, which, activo) -> marcadas[which] = activo)
                .setPositiveButton("Guardar", (d, w) -> guardarPrivacidad(marcadas))
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void guardarPrivacidad(boolean[] m) {
        boolean huella = m[3];
        if (huella && !huellaActivada) {
            KeyguardManager km = getSystemService(KeyguardManager.class);
            if (km == null || !km.isDeviceSecure()) {
                aviso("Primero pon un bloqueo de pantalla (huella o PIN) en el móvil");
                huella = false;
            }
        }
        bloquearAnuncios = m[0];
        forzarHttps = m[1];
        borrarAlCerrar = m[2];
        huellaActivada = huella;
        desbloqueado = true;
        prefs.edit()
                .putBoolean(K_ANUNCIOS, bloquearAnuncios)
                .putBoolean(K_HTTPS, forzarHttps)
                .putBoolean(K_BORRAR, borrarAlCerrar)
                .putBoolean(K_HUELLA, huellaActivada)
                .apply();
        aplicarSeguridadVentana();
        aviso("Guardado");
        web.reload();
    }

    private void confirmarBorrarDatos() {
        new AlertDialog.Builder(this)
                .setTitle("Borrar datos de navegación")
                .setMessage("Se borrarán cookies, historial, caché y datos de formularios. "
                        + "Tendrás que volver a iniciar sesión en las webs.")
                .setPositiveButton("Borrar", (d, w) -> {
                    borrarDatos();
                    aviso("Datos borrados");
                    cargar(INICIO);
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void borrarDatos() {
        CookieManager cm = CookieManager.getInstance();
        cm.removeAllCookies(null);
        cm.flush();
        WebStorage.getInstance().deleteAllData();
        web.clearCache(true);
        web.clearFormData();
        web.clearHistory();
        WebViewDatabase.getInstance(this).clearHttpAuthUsernamePassword();
    }

    /** Con huella activada, la app no sale en capturas ni en la vista de apps recientes. */
    private void aplicarSeguridadVentana() {
        if (huellaActivada) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_SECURE);
        }
    }

    @SuppressWarnings("deprecation")
    private void pedirHuella() {
        if (autenticando) return;
        autenticando = true;
        BiometricPrompt.Builder b = new BiometricPrompt.Builder(this)
                .setTitle("Navegador")
                .setSubtitle("Desbloquea para continuar");
        if (Build.VERSION.SDK_INT >= 30) {
            b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK
                    | BiometricManager.Authenticators.DEVICE_CREDENTIAL);
        } else {
            b.setDeviceCredentialAllowed(true);
        }
        try {
            b.build().authenticate(new CancellationSignal(), getMainExecutor(),
                    new BiometricPrompt.AuthenticationCallback() {
                        @Override
                        public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                            autenticando = false;
                            desbloqueado = true;
                            cortina.setVisibility(View.GONE);
                        }

                        @Override
                        public void onAuthenticationError(int code, CharSequence msg) {
                            autenticando = false; // sigue bloqueado; se puede reintentar con el botón
                        }
                    });
        } catch (Exception e) {
            autenticando = false;
            aviso("No se pudo pedir la huella");
        }
    }

    // =====================================================================
    //  Modo lectura (estilo Just Read, con Readability de Mozilla)
    // =====================================================================

    private void modoLectura() {
        final String url = web.getUrl();
        if (url == null || esInterna(url)) {
            aviso("Abre primero un artículo");
            return;
        }
        if (readabilityJs == null) readabilityJs = leerAsset("Readability.js");
        if (readabilityJs == null) {
            aviso("No se pudo cargar el modo lectura");
            return;
        }
        String script = "(function(){" + readabilityJs + "\n;try{"
                + "var a=new Readability(document.cloneNode(true)).parse();"
                + "if(!a||!a.content)return null;"
                + "return JSON.stringify({t:a.title||'',c:a.content,b:a.byline||'',s:a.siteName||'',"
                + "n:(a.textContent||'').trim().split(/\\s+/).length});"
                + "}catch(e){return null;}})();";
        web.evaluateJavascript(script, valor -> {
            if (valor == null || valor.equals("null")) {
                aviso("No he encontrado un artículo en esta página");
                return;
            }
            try {
                String json = new JSONArray("[" + valor + "]").getString(0);
                mostrarLectura(url, new JSONObject(json));
            } catch (Exception e) {
                aviso("No he encontrado un artículo en esta página");
            }
        });
    }

    private void mostrarLectura(String url, JSONObject o) {
        String nonce = Long.toHexString(new SecureRandom().nextLong());
        int tam = prefs.getInt(K_TAM, 19);
        String tema = prefs.getString(K_TEMA, "claro");
        String fuente = prefs.getString(K_FUENTE, "serif");
        int minutos = Math.max(1, Math.round(o.optInt("n", 0) / 200f));

        String titulo = TextUtils.htmlEncode(o.optString("t"));
        String autor = o.optString("b");
        String sitio = o.optString("s");
        StringBuilder meta = new StringBuilder();
        if (!sitio.isEmpty()) meta.append(TextUtils.htmlEncode(sitio)).append(" · ");
        if (!autor.isEmpty()) meta.append(TextUtils.htmlEncode(autor)).append(" · ");
        meta.append(minutos).append(" min de lectura");

        String html = "<!DOCTYPE html><html><head><meta charset='utf-8'>"
                + "<meta http-equiv='Content-Security-Policy' content=\"default-src 'none'; img-src * data: blob:; "
                + "media-src *; font-src * data:; style-src 'unsafe-inline'; script-src 'nonce-" + nonce + "'\">"
                + "<meta name='viewport' content='width=device-width,initial-scale=1'>"
                + "<title>" + titulo + "</title><style>"
                + "body{--fondo:#fff;--texto:#1f1f1f;--sec:#666;--enlace:#1a73e8}"
                + "body.sepia{--fondo:#f4ecd8;--texto:#3b2f1e;--sec:#7a6a55;--enlace:#8a5a00}"
                + "body.oscuro{--fondo:#121212;--texto:#e0e0e0;--sec:#9e9e9e;--enlace:#8ab4f8}"
                + "html{background:#fff}body{background:var(--fondo);color:var(--texto);margin:0;line-height:1.65;"
                + "-webkit-text-size-adjust:100%;min-height:100vh}"
                + "body.serif{font-family:Georgia,'Noto Serif',serif}body.sans{font-family:system-ui,Roboto,sans-serif}"
                + "#barra{position:sticky;top:0;display:flex;gap:6px;justify-content:center;flex-wrap:wrap;padding:8px;"
                + "background:var(--fondo);border-bottom:1px solid rgba(128,128,128,.25);z-index:9;"
                + "font-family:system-ui,sans-serif}"
                + "#barra a{color:var(--texto);text-decoration:none;font-size:14px;padding:6px 11px;border-radius:16px;"
                + "border:1px solid rgba(128,128,128,.35)}"
                + "#barra a.on{background:var(--enlace);color:#fff;border-color:var(--enlace)}"
                + "main{max-width:680px;margin:0 auto;padding:20px 20px 80px}"
                + "h1.tit{font-size:1.6em;line-height:1.25;margin:.3em 0}"
                + ".meta{color:var(--sec);font-size:.8em;font-family:system-ui,sans-serif;margin-bottom:1.5em}"
                + "main img,main video{max-width:100%;height:auto}figure{margin:1em 0}"
                + "a{color:var(--enlace)}pre{overflow:auto;white-space:pre-wrap}table{display:block;overflow:auto}"
                + "blockquote{border-left:3px solid var(--sec);margin:1em 0;padding-left:1em;color:var(--sec)}"
                + "body.borrando main *:active{outline:2px dashed #e53935}"
                + "</style></head>"
                + "<body class='" + tema + " " + fuente + "' style='font-size:" + tam + "px'>"
                + "<div id='barra'>"
                + "<a href='lectura://salir'>✕</a>"
                + "<a href='lectura://menos'>A−</a>"
                + "<a href='lectura://mas'>A+</a>"
                + "<a href='lectura://fuente'>Aa</a>"
                + "<a data-tema='claro' href='lectura://tema/claro'>Claro</a>"
                + "<a data-tema='sepia' href='lectura://tema/sepia'>Sepia</a>"
                + "<a data-tema='oscuro' href='lectura://tema/oscuro'>Oscuro</a>"
                + "<a href='#borrar' id='btnBorrar'>✂ Quitar</a>"
                + "</div><main><h1 class='tit'>" + titulo + "</h1>"
                + "<div class='meta'>" + meta + "</div>"
                + o.optString("c")
                + "</main><script nonce='" + nonce + "'>(function(){"
                + "var b=document.body;"
                + "function marcar(){var ts=document.querySelectorAll('[data-tema]');for(var i=0;i<ts.length;i++){"
                + "ts[i].classList.toggle('on',b.classList.contains(ts[i].getAttribute('data-tema')));}}"
                + "marcar();"
                + "document.getElementById('barra').addEventListener('click',function(e){"
                + "var a=e.target.closest('a');if(!a)return;var h=a.getAttribute('href');"
                + "if(h==='#borrar'){e.preventDefault();b.classList.toggle('borrando');a.classList.toggle('on');return;}"
                + "var t=h.replace('lectura://','');var px=parseInt(b.style.fontSize)||19;"
                + "if(t==='mas'){b.style.fontSize=Math.min(px+2,34)+'px';}"
                + "else if(t==='menos'){b.style.fontSize=Math.max(px-2,13)+'px';}"
                + "else if(t.indexOf('tema/')===0){b.classList.remove('claro','sepia','oscuro');b.classList.add(t.substr(5));marcar();}"
                + "else if(t==='fuente'){if(b.classList.contains('serif')){b.classList.replace('serif','sans');}"
                + "else{b.classList.replace('sans','serif');}}"
                + "});"
                + "document.querySelector('main').addEventListener('click',function(e){"
                + "if(!b.classList.contains('borrando'))return;e.preventDefault();e.stopPropagation();"
                + "var el=e.target;if(el&&el.tagName!=='MAIN'){el.remove();}},true);"
                + "})();</script></body></html>";

        web.loadDataWithBaseURL(url, html, "text/html", "utf-8", url);
    }

    /** Guarda las preferencias del modo lectura (el cambio visual ya lo hace la propia página). */
    private void manejarLectura(Uri u) {
        String accion = u.getHost() == null ? "" : u.getHost();
        String valor = u.getPath() == null ? "" : u.getPath().replace("/", "");
        switch (accion) {
            case "salir":
                if (!irAtras()) web.reload();
                break;
            case "mas":
                prefs.edit().putInt(K_TAM, Math.min(34, prefs.getInt(K_TAM, 19) + 2)).apply();
                break;
            case "menos":
                prefs.edit().putInt(K_TAM, Math.max(13, prefs.getInt(K_TAM, 19) - 2)).apply();
                break;
            case "tema":
                if (valor.equals("claro") || valor.equals("sepia") || valor.equals("oscuro")) {
                    prefs.edit().putString(K_TEMA, valor).apply();
                }
                break;
            case "fuente":
                String f = prefs.getString(K_FUENTE, "serif");
                prefs.edit().putString(K_FUENTE, f.equals("serif") ? "sans" : "serif").apply();
                break;
        }
    }

    private String leerAsset(String nombre) {
        try (InputStream in = getAssets().open(nombre)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toString("UTF-8");
        } catch (IOException e) {
            return null;
        }
    }

    // =====================================================================
    //  Menú y utilidades
    // =====================================================================

    private void mostrarMenu(View v) {
        PopupMenu p = new PopupMenu(this, v);
        p.getMenu().add(0, 1, 0, "Inicio");
        p.getMenu().add(0, 2, 1, "Adelante");
        p.getMenu().add(0, 3, 2, "Modo lectura");
        p.getMenu().add(0, 4, 3, "Webs bloqueadas");
        p.getMenu().add(0, 5, 4, "Privacidad");
        p.getMenu().add(0, 6, 5, "Borrar datos de navegación");
        p.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    cargar(INICIO);
                    return true;
                case 2:
                    if (web.canGoForward()) web.goForward();
                    return true;
                case 3:
                    modoLectura();
                    return true;
                case 4:
                    editarBloqueadas();
                    return true;
                case 5:
                    mostrarPrivacidad();
                    return true;
                case 6:
                    confirmarBorrarDatos();
                    return true;
            }
            return false;
        });
        p.show();
    }

    private View enMarco(View hijo) {
        int pad = (int) (20 * getResources().getDisplayMetrics().density);
        FrameLayout marco = new FrameLayout(this);
        marco.setPadding(pad, pad / 2, pad, 0);
        marco.addView(hijo);
        return marco;
    }

    private void aviso(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }

    private boolean abrirIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            cargar(i.getData().toString());
            return true;
        }
        return false;
    }

    // =====================================================================
    //  Ciclo de vida
    // =====================================================================

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        abrirIntent(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        abriendoExterno = false;
        if (huellaActivada && !desbloqueado) {
            cortina.setVisibility(View.VISIBLE);
            pedirHuella();
        } else {
            cortina.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (huellaActivada && !abriendoExterno) {
            desbloqueado = false;
            cortina.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        if (borrarAlCerrar && isFinishing()) borrarDatos();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_ARCHIVO && archivoCallback != null) {
            archivoCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            archivoCallback = null;
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        if (!irAtras()) super.onBackPressed();
    }
}
